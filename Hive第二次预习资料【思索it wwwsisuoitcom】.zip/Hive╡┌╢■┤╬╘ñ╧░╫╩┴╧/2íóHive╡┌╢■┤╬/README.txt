Hive_day02课程设计.md
	hive第二天课件
Hive可视化工具dbeaver
	Hive可视化工具dbeaver-level 3.md
		dbeaver安装文档
	dbeaver-ce-6.1.5-win32.win32.x86_64.zip
		dbeaver安装包
	hive-jdbc-1.1.0-cdh5.14.2-standalone.jar
		dbeaver驱动包
	Hive可视化工具dbeaver.mp4
		dbeaver安装视频
Hive_day02课程设计-level 1.md
	level 1级别；
	内容比较简单；课堂不讲，自己按文档实操学习